# No.50 v0.2 — 有限長の厳密結果と再帰証明失敗を分離した監査用パッケージ

**正式公開ではありません。独立再監査用 / AUDIT HOLD。**

**2026-11-02 v0.2.1 Windows修正:** 数学・論文・固定証拠JSONはv0.2から変更なし。Windows上のPython `Path.write_text()` がJSON改行をCRLF化し、配布証拠LF版とのバイト一致を破る問題を修正。3検証器とも `Path.write_bytes(data.encode("utf-8"))` として改行を固定。**v0.2では最初の比較で停止したため、Windowsでの全通しPASSは未確認。**

- 論文仮題: *Finite-Length Switching and a Failed Recurrence for Optimal Pairs in Binary Deletion Channels*
- Author: **Ryutaro Yonezu — Independent Researcher**
- Date: 2026-11-02
- Version: v0.2.1（パッケージのWindows修正のみ。論文版はv0.2を維持）
- License: **All rights reserved**
- Novelty: **INCONCLUSIVE**
- Human peer review: **Not human peer-reviewed**
- Mathematical proof: **Computer-assisted finite certificates; the infinite generalization remains unproved**
- Independent audit of v0.1: **PARTIAL (PASS寄り)**。新しいv0.2の第三者監査は **未実施**。

## 最重要の区別

| 区分 | 内容 | 状態 |
|---|---|---|
| 証明済み（計算機支援） | 長さ4〜8について全ての削除確率で最適距離多項式を分類 | v0.2の自己検証PASS |
| 証明済み（計算機支援） | 切替回数 S(4)=1, S(5)=1, S(6)=2, S(7)=3, S(8)=3 | v0.2の自己検証PASS |
| 証明済みの反例 | n=7、q=4/5の最適2組の共通ビット挿入256通りはn=8同じqの最適に届かない | v0.1の独立監査PASS、v0.2再現PASS |
| 観察 | 最適ペアの一部は異なるqへ移動して最適となる例がある | 個別例のみ、一般化不可 |
| 一般補助補題 | 固定nの局所最適性の安定性 | 初等証明、非新規 |
| **失敗** | **「任意の長さで切替回数は無限に増える」の証明** | **UNPROVED（予想は反証されていない）** |
| 未確定 | 先行研究からの独立した新規性 | **INCONCLUSIVE** |

## 監査・再現に必要なファイル

1. `paper/No50_v0.2_AUDIT_MANUSCRIPT_EN.pdf` / `.md`：英語論文原稿。採用した数学的主張と失敗経緯を明確に分割。
2. `audit/RESEARCH_CHRONOLOGY_JA.md`：No.50探索開始からFAIL、監査、v0.2補強までの時系列。
3. `audit/V01_TO_V02_CHANGELOG_JA.md`：監査役からの4指摘への対応と差分。
4. `audit/AUDIT_REQUEST_JA.md`：反証優先の第三者監査手順。
5. `code/verify_no50.py`：n4/5、n7の4点、n8の挿入256操作。
6. `code/verify_envelope_n6_n8.py`：n6〜8の全区間包絡線、正確な切替点の有理数隔離証明。
7. `code/independent_mask_audit.py`：削除マスク方式による別実装TV全ペア照合。
8. `evidence/*.json`：配布時の上記3検証器の実行結果。
9. `SHA256SUMS.txt`：全配布ファイルのSHA256（自分自身は除く）。

## Windowsでの再検算（家のPCで実行可能）

ZIPを展開して、展開先の `No50_v0.2.1_AUDIT_HOLD_20261102` フォルダでPowerShellを開き、以下を**一回だけ実行**。

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_audit_windows.ps1
```

このスクリプトは**全配布ファイルSHA256照合→検証器3本再実行→配布JSONとのバイト一致確認**の順に行う。どこか一か所でも失敗すれば停止してFAILを返す。出力は `audit_output/` にのみ保存し、配布証拠は上書きしない。

- 動作要件: **Windows PowerShell 5.1 / Python 3.10以上**。追加ライブラリ・GPU・インターネット・有料APIは不要。
- **PowerShell 5.1での実機動作はこの配布環境では未検証（v0.2.1の実機確認待ち）**。ユーザー側で実際に動かす必要がある。
- Pythonは `-I` モードで実行。元証拠を保護し、SHA不一致ならPython実行前に停止する。

## 論文の読み方

**有限結果の独立検証PASSと、新規性PASSは別。** v0.2の有限長定理に関する検証器は通ったが、先行文献の網羅的比較および新規コードの外部監査は未完了。GitHub・Zenodo公開はHOLD。n=9〜12や一般nの探索時の数値はこのパッケージの証明済み主張に含めない。
